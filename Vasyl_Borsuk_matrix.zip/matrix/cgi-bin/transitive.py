#!/usr/bin/env python3
import cgi
import html
import transitive_closure


form = cgi.FieldStorage()
size = form.getfirst("size",1)
mtx = []

# Creating list of lists, where every list is one line from matrix
for line in range(int(size)):
    line_lst = []
    for column in range(int(size)):
        name = '(' + str(line) + ',' + str(column) + ')'
        state = form.getfirst(name, "off")
        if state == 'on':
            line_lst.append(1)
        else:
            line_lst.append(0)
    mtx.append(line_lst)

# Making a transitive closure of matrix
res = transitive_closure.transitive_closure(mtx)

# Result webpage
print("Content-type: text/html\n")
print("""
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Matrix</title>
</head>
<body style="background: url(../pic/matrix.png) no-repeat; background-size: 100%; color: white;">
<div style="height: 150px; text-align: center;"><br><br>
    <a href="/"><img src="/pic/logo.png"></a>
</div>
<div style="font-size: 25pt; background: rgba(20,40,15,0.4); margin: 0px auto; width: 300px;">
    <table style="text-align: center; margin: 0px auto;" cellspacing="5" cellpadding="5">""")
# Table with results
for i in range(int(size)):
    print('<tr><td>|</td>')
    for j in range(int(size)):
        print('<td width=\'50\'>{}</td>'.format(res[i][j]))
    print('<td>|</td></tr>')
print("""
    </table>
</div>
</body>
</html>""")
