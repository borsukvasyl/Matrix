#!/usr/bin/env python3
import cgi
import html
import matrix_multiply


form = cgi.FieldStorage()
size = form.getfirst("size",1)
mrx1 = []
mrx2 = []

# Creating two lists of lists, where every list is one line from matrix
for i in range(int(size)):
    line_lst1 = []
    line_lst2 = []
    for j in range(int(size)):
        name1 = '(1,' + str(i) + ',' + str(j) + ')'
        name2 = '(2,' + str(i) + ',' + str(j) + ')'
        state1 = form.getfirst(name1, "off")
        state2 = form.getfirst(name2, "off")
        if state1 == 'on':
            line_lst1.append(1)
        else:
            line_lst1.append(0)
        
        if state2 == 'on':
            line_lst2.append(1)
        else:
            line_lst2.append(0)
    mrx1.append(line_lst1)
    mrx2.append(line_lst2)

# Making matrix multiplication
res = matrix_multiply.matrix_multiply(mrx1, mrx2)

# Result webpage
print("Content-type: text/html\n")
print("""
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Matrix</title>
</head>
<body style="background: url(../pic/matrix.png) no-repeat; background-size: 100%; color: white;">)
<div style="height: 150px; text-align: center;"><br><br>
    <a href="/"><img src="/pic/logo.png"></a>
</div>
<div style="font-size: 25pt; background: rgba(20,40,15,0.4); margin: 0px auto; width: 300px;">
    <table style="text-align: center; margin: 0px auto;" cellspacing="5" cellpadding="5">""")
# Table with results
for i in range(int(size)):
    print('<tr><td>|</td>')
    for j in range(int(size)):
        print('<td width=\'50\'>{}</td>'.format(res[i][j]))
    print('<td>|</td></tr>')
print("""
    </table>
</div>
</body>
</html>""")