#!/usr/bin/env python3
import cgi
import html
import matrix_relations


form = cgi.FieldStorage()
size = form.getfirst("size",1)
mrx = []


for i in range(int(size)):
    mrx1 = []
    for j in range(int(size)):
        name = '(' + str(i) + ',' + str(j) + ')'
        state = form.getfirst(name, "off")
        if state == 'on':
            mrx1.append(1)
        else:
            mrx1.append(0)
    mrx.append(mrx1)


res = matrix_relations.find_relations(mrx)


print("Content-type: text/html\n")
print("""<!DOCTYPE HTML>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Matrix.com</title>
        </head>
        <body style="background:url(../pic/matrix.png) no-repeat;background-size: 100%;color:white;">""")
print("<div style='height:150px;text-align:center;'><br><br><a href='/'><img src='/pic/logo.png'></a></div>")
print('<div style=\'font-size:25pt;background:rgba(20,40,15,0.4);margin:0px auto;width:300px;\'><table style=\'text-align:center;margin:0px auto;\' cellspacing=\'5\' cellpadding=\'5\'>')
for i in res:
    print('<tr><td>|</td>')
    print('<td>' + i + '</td>')
    print('<td>|</td></tr>')
print('</table></div>')
print("""</body>
        </html>""")
