#!/usr/bin/env python3
import cgi
import html
import matrix_relations


form = cgi.FieldStorage()
size = form.getfirst("size",1)
mrx = []

# Creating list of lists, where every list is one line from matrix
for line in range(int(size)):
    line_lst = []
    for column in range(int(size)):
        name = '(' + str(line) + ',' + str(column) + ')'
        state = form.getfirst(name, "off")
        if state == 'on':
            line_lst.append(1)
        else:
            line_lst.append(0)
    mrx.append(line_lst)

# Finding matrix relations
res = matrix_relations.find_relations(mrx)

# Result webpage
print("Content-type: text/html\n")
print("""
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Matrix</title>
</head>
<body style="background: url(../pic/matrix.png) no-repeat; background-size: 100%; color: white;">
<div style="height: 150px; text-align: center;"><br><br>
    <a href="/"><img src="/pic/logo.png"></a>
</div>
<div style="font-size: 25pt; background: rgba(20,40,15,0.4); margin: 0px auto; width: 300px;">
    <table style="text-align: center; margin: 0px auto;" cellspacing="5" cellpadding="5">""")
# Table with results
for i in res:
    print('<tr><td>|</td>')
    print('<td>' + i + '</td>')
    print('<td>|</td></tr>')
print("""
    </table>
</div>
</body>
</html>""")
